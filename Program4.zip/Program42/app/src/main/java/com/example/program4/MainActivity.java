package com.example.program4;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Fragmentone fragment1 = new Fragmentone();
        FragmentTwo fragment2 = new FragmentTwo();
        FragmentManager managerF = getSupportFragmentManager();

        FragmentTransaction Ftransaction = managerF.beginTransaction();

        Ftransaction.add(R.id.frameLayout, fragment1);

        Button b1 = findViewById(R.id.button);
        Button b2 = findViewById(R.id.button2);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentManager managerF = getSupportFragmentManager();
                FragmentTransaction Ftransaction = managerF.beginTransaction();
                Ftransaction.replace(R.id.frameLayout, fragment1);
                //replace the  Fragment
                Toast.makeText(MainActivity.this, "Changed to Fragment1", Toast.LENGTH_LONG).show();
                Ftransaction.commit();
                //Commit the changes in the Activity Main.
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentManager managerF = getSupportFragmentManager();
                FragmentTransaction Ftransaction = managerF.beginTransaction();
                Ftransaction.replace(R.id.frameLayout, fragment2);
                Toast.makeText(MainActivity.this, "Changed to Fragment1", Toast.LENGTH_LONG).show();
                Ftransaction.commit();
            }
        });


    }
}

